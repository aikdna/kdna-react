# Security and authority boundary

This PD287 candidate delegates container admission to the exact public Core/browser RC and remote response admission to the exact public Read/transport RC. It carries no independent protocol validator or raw-payload parser.

Selection and endpoint/session bindings are explicit. Local selection objects are opaque capabilities of this client module and cannot be forged by copying their visible fields. A remote view preserves the official receiver's proof limits and does not create a Core snapshot, admitted request, Host witness, authorization or action capability. Remote identity, authorization, current revocation, receipt delivery and network replay remain unproven. Fetch does not expose raw HTTP framing. Display remote strings with safe text APIs.

Use AbortSignal, dispose the client, and release selections when finished. Credentials are omitted and redirects are rejected. No license key, activation endpoint, implicit provider, retry, or server fallback is implemented. Custom Fetch implementations are application-owned; logical cancellation prevents late publication, while an uncooperative Fetch keeps its bounded concurrency slot until it settles.

Report defects with the local candidate and exact dependency hashes. Do not attach private assets, tokens, raw license keys, or secret response bodies. This local artifact has no release authorization.
